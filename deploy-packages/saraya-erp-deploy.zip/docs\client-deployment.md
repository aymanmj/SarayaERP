# 📋 دليل التنصيب الكامل لنظام Saraya ERP

## نظرة عامة

هذا الدليل يشرح كيفية تنصيب نظام Saraya ERP على سيرفر العميل باستخدام السكربتات الآلية.

---

## 🗂️ البنية

```
┌─────────────────────────────────────────────────────────────────────────┐
│                              أنت (المطور)                                │
│                     جهازك + Tailscale للوصول البعيد                      │
│                                    │                                    │
│                          ┌─────────┴─────────┐                          │
│                          │   Tailscale VPN   │                          │
│                          └─────────┬─────────┘                          │
│          ┌─────────────────────────┼─────────────────────────┐         │
│          │                         │                         │         │
│          ▼                         ▼                         ▼         │
│   ┌──────────────┐          ┌──────────────┐          ┌──────────────┐ │
│   │   عميل 1     │          │   عميل 2     │          │   عميل 3     │ │
│   │ Ubuntu Server│          │ Ubuntu Server│          │ Ubuntu Server│ │
│   │      +       │          │      +       │          │      +       │ │
│   │ أجهزة Windows│          │ أجهزة Windows│          │ أجهزة Windows│ │
│   └──────────────┘          └──────────────┘          └──────────────┘ │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 🚀 الطريقة السريعة (سطر واحد)

```bash
curl -fsSL https://raw.githubusercontent.com/aymanmj/SarayaERP/main/scripts/install.sh | sudo bash
```

---

## 📦 الطريقة الكاملة (حزمة النشر)

### الخطوة 1: إنشاء حزمة النشر (على جهازك)

```bash
cd /path/to/SarayaERP
./scripts/create-deploy-package.sh
```

**الناتج:** `deploy-packages/saraya-erp-deploy-XXXXXX.zip`

### الخطوة 2: نقل الحزمة للسيرفر

**عبر USB:**
```bash
# انسخ الملف على USB
# ثم على السيرفر:
cp /media/usb/saraya-erp-deploy-*.zip ~/
```

**عبر SCP:**
```bash
scp saraya-erp-deploy-*.zip user@SERVER_IP:~/
```

### الخطوة 3: التثبيت على السيرفر

```bash
# فك الضغط
unzip saraya-erp-deploy-*.zip
cd saraya-erp-deploy-*

# تشغيل التثبيت
sudo ./INSTALL.sh
```

---

## 📝 ما يطلبه السكربت

أثناء التثبيت، سيسألك السكربت عن:

| المطلوب | المثال | ملاحظات |
|---------|--------|---------|
| اسم المؤسسة | `amal-clinic` | بالإنجليزية، بدون مسافات |
| Tailscale Auth Key | `tskey-auth-xxx` | اختياري، للوصول البعيد |
| GitHub Username | `aymanmj` | للوصول لـ GHCR |
| GitHub PAT | `ghp_xxxx` | مع صلاحية `read:packages` |
| مسار ملف الرخصة | `/path/to/saraya.lic` | اختياري |

---

## ✅ بعد التثبيت

### الوصول للنظام

| الخدمة | الرابط |
|--------|--------|
| التطبيق | `http://SERVER_IP` |
| Portainer | `http://SERVER_IP:9000` |
| Grafana | `http://SERVER_IP:3001` |

### أجهزة Windows (المستخدمين)

**لا يحتاجون تثبيت أي شيء!**
1. فتح المتصفح
2. الذهاب لـ `http://SERVER_IP`
3. استخدام النظام

### إضافة اسم مختصر (اختياري)

على أجهزة Windows، افتح `C:\Windows\System32\drivers\etc\hosts` كـ Administrator وأضف:
```
192.168.1.10    saraya
```

الآن يمكنهم الوصول عبر: `http://saraya`

---

## 🔧 السكربتات المتاحة

```
/opt/saraya-erp/scripts/
├── install.sh            # التثبيت التلقائي
├── update.sh             # تحديث النظام
├── health-check.sh       # فحص صحة النظام
├── backup.sh             # نسخ احتياطي يدوي
├── setup-ghcr.sh         # إعداد GHCR
├── uninstall.sh          # إزالة النظام
└── create-deploy-package.sh  # إنشاء حزمة النشر
```

### أوامر الإدارة

```bash
cd /opt/saraya-erp

# فحص صحة النظام
./scripts/health-check.sh

# تحديث النظام
./scripts/update.sh

# نسخة احتياطية
./scripts/backup.sh

# عرض السجلات
docker compose -f docker-compose.production.yml logs -f

# إعادة تشغيل خدمة معينة
docker compose -f docker-compose.production.yml restart backend

# إيقاف النظام
sudo systemctl stop saraya-erp

# تشغيل النظام
sudo systemctl start saraya-erp
```

---

## 🌐 الوصول البعيد (لك كمطور)

### إعداد Tailscale على جهازك

1. حمّل Tailscale: https://tailscale.com/download
2. سجّل دخول
3. ستجد جميع سيرفرات العملاء في القائمة

### الوصول للسيرفرات

```bash
# SSH
ssh user@saraya-amal-clinic

# Portainer
http://saraya-amal-clinic:9000

# تحديث عبر Watchtower API
curl -H "Authorization: Bearer $TOKEN" http://saraya-amal-clinic:8080/v1/update
```

---

## ⚠️ استكشاف الأخطاء

### الخدمة لا تعمل

```bash
# فحص الحالة
./scripts/health-check.sh

# عرض السجلات
docker logs saraya_backend
docker logs saraya_frontend
```

### مشكلة في الاتصال

```bash
# التحقق من الشبكة
ping SERVER_IP
curl http://SERVER_IP:3000/api/health
```

### إعادة تثبيت كامل

```bash
# إزالة ثم تثبيت
sudo ./scripts/uninstall.sh
sudo ./scripts/install.sh
```
