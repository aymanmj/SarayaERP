#!/bin/bash
# Quick Installer - يشغل سكربت التثبيت الكامل
echo "Starting Saraya ERP Installation..."
sudo bash scripts/install.sh
